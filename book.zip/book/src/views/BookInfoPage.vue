<template>
  <h1 class="mb-4">Garry Potter</h1>
  <p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce suscipit sit amet erat eu
    iaculis. Mauris elementum aliquam nisl. Vestibulum tincidunt congue magna a iaculis. Vivamus
    interdum tincidunt dolor, at volutpat velit mollis quis. Interdum et malesuada fames ac ante
    ipsum primis in faucibus. Ut rhoncus, neque a efficitur volutpat, metus massa condimentum est,
    et ornare libero ligula ultricies ex. Vivamus placerat iaculis est ac elementum. Quisque
    id metus id nulla fringilla egestas. Vivamus quis nibh non sem auctor hendrerit. Maecenas
    urna orci, pretium eget luctus vitae, finibus a turpis. Aenean id nisi sagittis, congue
    tellus ac, porttitor purus. Duis vitae velit ut risus pellentesque aliquet at sit amet erat.
    Donec elementum lacus neque, non accumsan sem tristique scelerisque. Vestibulum fermentum
    aliquam lacus, non viverra ante sodales vel. Phasellus mattis ante enim, lacinia suscipit
    quam fringilla sit amet.
  </p>
  <p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce suscipit sit amet erat eu
    iaculis. Mauris elementum aliquam nisl. Vestibulum tincidunt congue magna a iaculis. Vivamus
    interdum tincidunt dolor, at volutpat velit mollis quis. Interdum et malesuada fames ac ante
    ipsum primis in faucibus. Ut rhoncus, neque a efficitur volutpat, metus massa condimentum est,
    et ornare libero ligula ultricies ex. Vivamus placerat iaculis est ac elementum. Quisque
    id metus id nulla fringilla egestas. Vivamus quis nibh non sem auctor hendrerit. Maecenas
    urna orci, pretium eget luctus vitae, finibus a turpis. Aenean id nisi sagittis, congue
    tellus ac, porttitor purus. Duis vitae velit ut risus pellentesque aliquet at sit amet erat.
    Donec elementum lacus neque, non accumsan sem tristique scelerisque. Vestibulum fermentum
    aliquam lacus, non viverra ante sodales vel. Phasellus mattis ante enim, lacinia suscipit
    quam fringilla sit amet.
  </p>
</template>

<script>
export default {
  name: "BookInfoPage"
}
</script>

<style scoped>

</style>