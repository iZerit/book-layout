<template>
  <div class="row bg-dark text-light p-5 text-center">
    <div class="col display-4">
      &copy; All rights reserved
    </div>
  </div>
</template>

<script>
export default {
  name: "FooterRow"
}
</script>

<style scoped>

</style>