<template>
  <div class="row">

    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <router-link to="/book-info" href="./book.html" class="btn btn-primary">Batafsil</router-link>
        </div>
      </div>
    </div>

    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <a href="#" class="btn btn-primary">Batafsil</a>
        </div>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <a href="#" class="btn btn-primary">Batafsil</a>
        </div>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <a href="#" class="btn btn-primary">Batafsil</a>
        </div>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <a href="#" class="btn btn-primary">Batafsil</a>
        </div>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <a href="#" class="btn btn-primary">Batafsil</a>
        </div>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <a href="#" class="btn btn-primary">Batafsil</a>
        </div>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="./harry.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Garry Potter</h5>
          <p class="card-text">Garry Potter va himatlar toshi</p>
          <a href="#" class="btn btn-primary">Batafsil</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BooksRow"
}
</script>

<style scoped>

</style>