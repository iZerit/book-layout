<template>
  <div class="col-12 col-md-3 px-3 px-md-0">
    <div class="list-group">
      <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
        The current link item
      </a>
      <a href="#" class="list-group-item list-group-item-action">A second link item</a>
      <a href="#" class="list-group-item list-group-item-action">A third link item</a>
      <a href="#" class="list-group-item list-group-item-action">A fourth link item</a>
      <a class="list-group-item list-group-item-action disabled">A disabled link item</a>
    </div>
  </div>
</template>

<script>
export default {
  name: "CategoriesCol"
}
</script>

<style scoped>

</style>